# ultimate-tic-tac-toe-AI
to start the game download the files and run uttt2 main function
 
the game base code : https://github.com/pulkitmaloo/Ultimate-Tic-Tac-Toe
